# Math-Docs
Things I've written in LaTeX for various Maths classes &amp; projects

## Included Files:

1. MATH 466 - Project 1 - The Distribution of Mantissas.pdf
	* A discussion on the reciprocal distribution of mantissas in numbers randomly sampled from the real world (also known as Benford's Law), including some simulations written in Python and an additional discussion on the distribution of rounding error found in Numerical Computations

2. MATH 466 - Project 2 - Adaptive Quadrature.pdf
	* A discussion on some simple methods of Numerical Quadrature (e.g. the Trapezoid Rule, Simpson's rule, etc.), including a comparison of the errors associated with these methods & ways these methods can be improved

3. Moran, Miles - Paper #1 - Riemann Hypothesis FINAL.pdf
	* A summary / explanation of the Riemann Hypothesis, including a brief history and an explanation of its significance
	* Written for an introductory proofs / "Intro to Higher Maths" course

4. Research_Paper_Intro.pdf
	* An introduction to Discrete-Time Markov Chains and Markov Processes assuming only prior knowledge of introductory probability and introductory Linear Algebra. Does NOT discuss the relationship between Markov Chains and Dynamical Systems.
	* Written as an introduction to a research paper than is currently on hold
