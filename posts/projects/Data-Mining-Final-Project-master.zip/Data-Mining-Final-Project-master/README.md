# **Introduction, Decisions, and Responsibilities** 

This project is for a course on Data Mining (CS 458) at the University of Nevada, Reno. Task descriptions are given in the `0-Project Description-2019.pdf` file included herein. For context, students had to complete Task 1 as well as one of Tasks 2 and 3. 

<br />

When deciding whether we should attempt Task 2 or Task 3 for our other task (in addition to Task 1), we had two major considerations:
1. Task 2 contains *time-series* data rather than a traditional table with feature columns.
2. Task 3 had three components (predict car; predict customer; partition dataset) instead of just one.

Each task had its own challenges, as Task 2 would require specific time-series algorithms and Task 3 would require specific rule-building algorithms. We decided to stick with Task 2.

---

# **Task 1**
For Task 1, the driver code is all contained in the main() function. It works in the following way:
1.	`main()` calls the `load_data()` subroutine, which uses `pd.read_csv()` to get the data and labels from GitHub and then stores them as a `pd.DataFrame` and a `pd.Series`, respectively. The `requests` and the `io` library are specifically imported to help pull these files from Github. The `load_data()` function converts each `DataFrame` into a `csr_matrix` (thus saving 90% of the space required by a dense matrix) and asserts that the shape of every matrix is correct. In particular, it checks to make sure that each object has a label, and that each matrix has the same number of attributes. Finally, the subroutine packages every `csr_matrix` into a dictionary called `matrix` and every `Series` into a dictionary called `labels` before returning everything to `main()`. 
2.	For each classifier specified under the variable `CLF_NAMES`, `main()` does the following: 
    * First, it calls `get_fitted_model()` in order to get the model specified, fit it to the training data, and then store the result in the variable `clf`. Note that the parameters for each model are hard-coded to be the best parameters we found during experimentation. 
    * Then, it uses `clf` to classify the test dataset with the `classify_test_data()` subroutine. This subroutine simply uses the `predict()` function built into each classifier. If the `download` parameter is `True`, the subroutine will download the labels as a `.csv` file. 
    * Along the way, the time taken to train the model and the time taken to predict the test labels are recorded for later plotting.
    * Finally, the training and verification errors are recorded using the `score()` function built into each classifier. 

3.	After all the heavy-lifting has been performed, the `plot_results()` function is called to, as the name suggests, plot the results using `MatPlotLib`. 

<br />

You may have noticed that there is no mention of PreProcessing in the code above. Most groups used some kind of dimensionality reduction in their code. We did not. This is because scaling the data seemed to be a universal prerequisite for applying a dim-reduction algorithm; and, unfortunately, scaling was incredibly hard for us. The RobustScalar included in SKLearn is supposed to be robust to outliers; however, it doesn’t work well with sparse data. Additionally, we found that other forms of scaling resulted in strange behavior – perhaps because we scaled each dataset separately instead of jointly. In the end, our lack of preprocessing resulted in high training times for the MLPClassifier and the SVC. However, the error rates did not suffer at all, and for this reason we decided to forego preprocessing altogether in favor of working on Task 3.  

<br />

As it stands, the models used (and the parameters for those models) are hardcoded. Although the code is modular enough to add in 5-10 more different classifiers very easily, I thought it was sufficient to just include 4 models that, together, represent both traditional techniques (e.g. decision trees and naïve-bayes) as well as newer, deep-learning techniques (e.g. multi-layer-perceptron networks). The parameters for each model are the best parameters we could find after experimentation with SKLearn’s RandomizedSearchCV tool. 

<br />

One curiosity I found in this parameter searching was the fact that the DecisionTree model almost never really suffered from overfitting. Although the training error went down to 0 in every case, the verification error never rose above 5%.

<br />

Our Results may be summarized with the tables presented in our powerpoint slides: 

Classifier | Time to Train (s) | Time to Predict (s) | Training Error (%) | Verification Error (%)
--- | --- | --- | --- | ---
DecisionTree           | 0.43 | 0.00 | 0  | 5
Naive Bayes            | 0.00 | 0.00 | 4  | 6
Support Vector Machine |21.98 | 4.46 | 6  | 30
Multi-Layer Perceptron |21.61 | 0.02 | 0  | 2



As you can see, the results were best for the MLPClassifier; and, for this reason, we have chosen it as the model we would like to use for the task of predicting test labels. 

<br />

Several design choices were made along the way. As someone familiar with Python, I have had trouble reading my own code in the past because of Python’s implicit type declarations. For this reason, I added function annotations to every subroutine, and I used the docstring conventions specified in PEP257. Additionally, although I would have liked to store the IO-related tasks in a separate class, I found that importing modules into Google Colab is terribly painful – so I decided to leave all the code in one place. 

<br />

NOTE: The driver code for Task 1 is currently set up to compare all 4 classifiers without downloading the predicted labels for any of those classifiers. If desired, change `download=True` in the list of parameters when calling classify_test_data() on line 42. 

---

# **Task 2**

The version of Task 2 included herein is my continuation of my group-mate's code that went unfinished. When writing this report, I learned that Vanessa's code wasn't as complete as the project outline specifies it should be. Additionally, she did not comment her code as requested. For this reason, I've included my rendition of her code using the same classifiers and a similar datetime-to-attributes technique. In particular, the project description tells us to construct a classifier which infers from nearby data collection sites -- mine makes some attempt at this, while Vanessa's only forecasts data for one site.  

Vanessa's code works as follows:
1. For the West Sagebrush site, retrieve the data with `pandas.read_csv()` and impute all missing values with the mean wind speed.
2. Take each date-time value from the dataset and convert it into a list for year, month, day, hour, minute, and second. Use these lists as the new X values for the dataset. 
3. Test a Decision Tree Model on the newly-made X and y.
4. Test a K-Nearest Neighbors model on the newly-made X and y. 

My code works much in the same way, albeit slightly more concise: 
1. For EACH site in the dictionary `URLS`, perform parts (1) and (2) of Vanessa's code. Additionally, add a tag to each dataset indicating what site the data came from.
2. Combine the data from each site into a couple of all-encompassing datasets, `X` and `y`. 
3. Split these larger datasets into training and testing sets, and use the training subset to train a Decision Tree and a KNN model.
4. For each of these models, plot the predicted windspeed against the true windspeed for the first 200 10-minute time intervals. 

The results for Vanessa's code is as follows:

Classifier | Mean Absolute Error | Root Mean Squared Error | Coeff. of Determination
--- | --- | --- | ---
Decision Trees | 0.393 | 0.567 | 0.869
K Nearest Neighbors | 0.963 | 1.25 | 0.36


The results for my code is as follows:

Classifier | Mean Absolute Error | Root Mean Squared Error 
--- | --- | --- 
Decision Trees | 0.549 | 0.879 
K Nearest Neighbors | 1.036 | 1.478

My plot of `y_pred` vs `y_verif` using Decision Trees for the first 200 time intervals:
![For Decision Trees](FIGURE_DCT.png)

My plot of `y_pred` vs `y_verif` using KNN for the first 200 time intervals:
![For KNN](FIGURE_KNN.png)

In both Vanessa's and my own code, the results were good from both classifiers (with less-than-1.5 mph windspeed errors), but with results heavily in favor of Decision Trees over KNN. I am not surprised that my results are slightly worse than Vanessa's, considering that my code is trained on all 7 sites and not *just* the West-Sagebrush site. 

<br />

As with Task 1, the design choice was made in my code to use function annotations to make things more readable. Vanessa and I also decided to split the original datetime attribute into several attributes for month, day, etc. so that we could apply traditional regression techniques (e.g DCT, KNN) instead of time-series specific techniques (e.g. ARMAX). 

