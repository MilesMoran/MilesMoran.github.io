As the description implies, this is just a dinky little script I wrote to visualize / calculate the average length of a chord in a unit circle using P5.js. I wrote it a few years back when I saw a video of someone using calculus to do the same thing. Note that p5.min.js is not my creation -- just a dependency.

A simple proof has been included
